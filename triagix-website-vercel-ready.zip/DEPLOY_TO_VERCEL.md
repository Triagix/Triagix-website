# Deploy Triagix Website

Upload the CONTENTS of this folder to the GitHub repository root, not the zip file itself.

The repository root should contain:
- package.json
- vercel.json
- public/index.html
- src/App.js
- src/index.js

Then import the repo in Vercel and deploy.

Vercel settings:
- Framework preset: Create React App (or Auto)
- Root directory: ./
- Build command: npm run build
- Output directory: build

Domain:
- triagix.ai
- www.triagix.ai
