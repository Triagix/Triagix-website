# Triagix Website

Official website for [Triagix](https://triagix.ai) — the AI-powered triage and routing platform for telehealth contact centers.

## Getting Started

```bash
npm install
npm start
```

## Deploy to Vercel

1. Push this repo to GitHub
2. Go to [vercel.com](https://vercel.com) and import the repository
3. Vercel auto-detects React — click Deploy
4. Add your custom domain `triagix.ai` in Vercel settings

## Build for Production

```bash
npm run build
```

## Tech Stack

- React 18
- Google Fonts — Syne, DM Sans, JetBrains Mono
- Pure CSS animations — no external UI libraries

## Contact

david@triagix.ai · triagix.ai · Atlanta, GA

© 2026 Exemplaryoutlook LLC DBA Triagix
